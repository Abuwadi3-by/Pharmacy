﻿namespace pharmasese
{
    partial class ExpiredForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvExpired = new System.Windows.Forms.DataGridView();
            this.btnDestroy = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvExpired)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvExpired
            // 
            this.dgvExpired.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvExpired.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvExpired.Location = new System.Drawing.Point(222, 12);
            this.dgvExpired.Name = "dgvExpired";
            this.dgvExpired.RowHeadersWidth = 51;
            this.dgvExpired.RowTemplate.Height = 24;
            this.dgvExpired.Size = new System.Drawing.Size(571, 345);
            this.dgvExpired.TabIndex = 0;
            // 
            // btnDestroy
            // 
            this.btnDestroy.Location = new System.Drawing.Point(36, 24);
            this.btnDestroy.Name = "btnDestroy";
            this.btnDestroy.Size = new System.Drawing.Size(93, 72);
            this.btnDestroy.TabIndex = 1;
            this.btnDestroy.Text = "اتلاف الادوية ";
            this.btnDestroy.UseVisualStyleBackColor = true;
            this.btnDestroy.Click += new System.EventHandler(this.btnDestroy_Click);
            // 
            // ExpiredForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnDestroy);
            this.Controls.Add(this.dgvExpired);
            this.Name = "ExpiredForm";
            this.Text = "Expired";
            this.Load += new System.EventHandler(this.ExpiredForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvExpired)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvExpired;
        private System.Windows.Forms.Button btnDestroy;
    }
}