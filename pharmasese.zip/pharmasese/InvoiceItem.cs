﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pharmasese
{
    public class InvoiceItem
    {
        public string MedicineName { get; set; }
        public string CompanyName { get; set; }
        public int QuantitySold { get; set; }
        public double PricePerUnit { get; set; }
        public double TotalItemPrice => QuantitySold * PricePerUnit;
    
}
  
}

