﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pharmasese
{
    public partial class MedicinesForm : Form
    {
        public MedicinesForm()
        {
            InitializeComponent();
        }

        private void MedicinesForm_Load(object sender, EventArgs e)
        {
            dgvMedicines.DataSource = null;
            dgvMedicines.DataSource = Database.Medicines;


            cmbCompanies.Items.Clear();
            foreach (var comp in Database.Companies)
            {
                cmbCompanies.Items.Add(comp.Name);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtTradeName.Text == "" || txtScienceName.Text == "" || txtQuantity.Text == "" || txtPrice.Text == "" || cmbCompanies.SelectedItem == null)
            {
                MessageBox.Show("الرجاء تعبئة جميع الحقول واختيار شركة!", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            
            Medicine med = new Medicine
            {
                ID = Database.Medicines.Count + 1,
                TradeName = txtTradeName.Text,
                ScienceName = txtScienceName.Text,
                Quantity = int.Parse(txtQuantity.Text),
                Price = double.Parse(txtPrice.Text),
                CompanyName = cmbCompanies.SelectedItem.ToString(),
                ExpiryDate = dtpExpiry.Value
            };

            
            Database.Medicines.Add(med);
            dgvMedicines.DataSource = null;
            dgvMedicines.DataSource = Database.Medicines;

            MessageBox.Show("تم إضافة الدواء بنجاح", "نجاح", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvMedicines.CurrentRow != null)
            {
                Medicine selected = (Medicine)dgvMedicines.CurrentRow.DataBoundItem;
                Database.Medicines.Remove(selected);

                dgvMedicines.DataSource = null;
                dgvMedicines.DataSource = Database.Medicines;
                MessageBox.Show("تم الحذف بنجاح", "نجاح", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void txtSearchCompany_TextChanged(object sender, EventArgs e)
        {
            
            var filtered = Database.Medicines.Where(m => m.CompanyName.ToLower().Contains(txtSearchCompany.Text.ToLower())).ToList();
            dgvMedicines.DataSource = null;
            dgvMedicines.DataSource = filtered;
        }

        private void btnSortName_Click(object sender, EventArgs e)
        {
           
  
             var sorted = Database.Medicines.OrderBy(m => m.TradeName).ToList();
            dgvMedicines.DataSource = null;
            dgvMedicines.DataSource = sorted;
        }

        private void btnSortPrice_Click(object sender, EventArgs e)
        {
            var sorted = Database.Medicines.OrderBy(m => m.Price).ToList();
            dgvMedicines.DataSource = null;
            dgvMedicines.DataSource = sorted;
        }

        private void btnSortExpiry_Click(object sender, EventArgs e)
        {
            
  var sorted = Database.Medicines.OrderBy(m => m.ExpiryDate).ToList();
            dgvMedicines.DataSource = null;
            dgvMedicines.DataSource = sorted;
        }
    }
}
