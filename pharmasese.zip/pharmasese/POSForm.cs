﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pharmasese
{
    public partial class POSForm : Form
    {
        List<InvoiceItem> Basket = new List<InvoiceItem>();
        double invoiceTotal = 0;

        public POSForm()
        {
            InitializeComponent();
        }

        private void POSForm_Load(object sender, EventArgs e)
        {
            cmbPOSMedicines.Items.Clear();
            foreach (var med in Database.Medicines)
            {
               
                cmbPOSMedicines.Items.Add(med.TradeName);
            }
        }

        private void btnAddToBasket_Click(object sender, EventArgs e)
        {
            if (cmbPOSMedicines.SelectedItem == null || txtSaleQty.Text == "")
            {
                MessageBox.Show("الرجاء اختيار دواء وتحديد الكمية!", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string selectedMedName = cmbPOSMedicines.SelectedItem.ToString();
            int qtyToSell = int.Parse(txtSaleQty.Text);

           
            Medicine stockMed = Database.Medicines.FirstOrDefault(m => m.TradeName == selectedMedName);

            if (stockMed == null) return;

          
            if (stockMed.Quantity < qtyToSell)
            {
                MessageBox.Show($"الكمية المطلوبة غير متوفرة! المتوفر هو: {stockMed.Quantity}", "خطأ في الكمية", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            
            if (stockMed.ExpiryDate < DateTime.Now)
            {
                MessageBox.Show("عذراً، هذا الدواء منتهي الصلاحية ولا يمكن بيعه!", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                return;
            }

         
            InvoiceItem item = new InvoiceItem
            {
                MedicineName = stockMed.TradeName,
                CompanyName = stockMed.CompanyName,
                QuantitySold = qtyToSell,
                PricePerUnit = stockMed.Price
            };

            Basket.Add(item);

           
            dgvBasket.DataSource = null;
            dgvBasket.DataSource = Basket;

            
            invoiceTotal += item.TotalItemPrice;
            lblTotalInvoice.Text = "إجمالي الفاتورة: " + invoiceTotal.ToString() + " ل.س";

            txtSaleQty.Clear();
        }

        private void btnCheckout_Click(object sender, EventArgs e)
        {
            if (Basket.Count == 0)
            {
                MessageBox.Show("السلة فارغة! قم بإضافة أدوية أولاً.", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            
            foreach (var item in Basket)
            {
                Medicine stockMed = Database.Medicines.FirstOrDefault(m => m.TradeName == item.MedicineName);
                if (stockMed != null)
                {
                    stockMed.Quantity -= item.QuantitySold; 
                }
            }

            
            Invoice inv = new Invoice
            {
                InvoiceID = Database.Invoices.Count + 1,
                SaleDate = DateTime.Now,
                Items = new List<InvoiceItem>(Basket),
                TotalInvoicePrice = invoiceTotal
            };
            Database.Invoices.Add(inv);

           
            string invoiceDetails = $"--- فاتورة مبيعات رقم: {inv.InvoiceID} ---\n";
            invoiceDetails += $"التاريخ: {inv.SaleDate.ToString("yyyy-MM-dd HH:mm")}\n\n";
            invoiceDetails += "الأدوية المباعة:\n";

            foreach (var item in Basket)
            {
                invoiceDetails += $"- {item.MedicineName} | الكمية: {item.QuantitySold} | السعر: {item.PricePerUnit} | المجموع: {item.TotalItemPrice}\n";
            }

            invoiceDetails += $"\nالمبلغ الإجمالي الفعلي: {invoiceTotal} ل.س";

            
            MessageBox.Show(invoiceDetails, "تفاصيل الفاتورة المستعرضة", MessageBoxButtons.OK, MessageBoxIcon.Information);

           
            Basket.Clear();
            dgvBasket.DataSource = null;
            invoiceTotal = 0;
            lblTotalInvoice.Text = "إجمالي الفاتورة: 0 ل.س";
        }
    }
}
