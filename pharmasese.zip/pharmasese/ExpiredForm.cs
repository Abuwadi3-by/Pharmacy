﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pharmasese
{
    public partial class ExpiredForm : Form
    {
        public ExpiredForm()
        {
            InitializeComponent();
        }

        private void ExpiredForm_Load(object sender, EventArgs e)
        {
            RefreshExpiredGrid();
        }
        private void RefreshExpiredGrid()
        {
            var expiredList = Database.Medicines.Where(m => m.ExpiryDate < DateTime.Now).ToList();
            dgvExpired.DataSource = null;
            dgvExpired.DataSource = expiredList;
        }

        private void btnDestroy_Click(object sender, EventArgs e)
        {
            
            var expiredList = Database.Medicines.Where(m => m.ExpiryDate < DateTime.Now).ToList();

            if (expiredList.Count == 0)
            {
                MessageBox.Show("لا يوجد أي أدوية منتهية الصلاحية لإتلافها!", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

           
            foreach (var med in expiredList)
            {
                Database.Medicines.Remove(med);
            }

           
            RefreshExpiredGrid();
            MessageBox.Show("تم إتلاف الأدوية المنتهية بنجاح وحذفها من المستودع!", "نجاح العملية", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
