﻿namespace pharmasese
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnOpenMediciines = new System.Windows.Forms.Button();
            this.btnOpenCompanies = new System.Windows.Forms.Button();
            this.btnOpenExpired = new System.Windows.Forms.Button();
            this.btnOpenPOS = new System.Windows.Forms.Button();
            this.btnOpenReports = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnOpenMediciines
            // 
            this.btnOpenMediciines.Location = new System.Drawing.Point(301, 30);
            this.btnOpenMediciines.Name = "btnOpenMediciines";
            this.btnOpenMediciines.Size = new System.Drawing.Size(167, 50);
            this.btnOpenMediciines.TabIndex = 0;
            this.btnOpenMediciines.Text = "ادارة الادوية";
            this.btnOpenMediciines.UseVisualStyleBackColor = true;
            this.btnOpenMediciines.Click += new System.EventHandler(this.btnOpenMediciines_Click);
            // 
            // btnOpenCompanies
            // 
            this.btnOpenCompanies.Location = new System.Drawing.Point(301, 99);
            this.btnOpenCompanies.Name = "btnOpenCompanies";
            this.btnOpenCompanies.Size = new System.Drawing.Size(167, 44);
            this.btnOpenCompanies.TabIndex = 1;
            this.btnOpenCompanies.Text = "ادارة الشركات ";
            this.btnOpenCompanies.UseVisualStyleBackColor = true;
            this.btnOpenCompanies.Click += new System.EventHandler(this.btnOpenCompanies_Click);
            // 
            // btnOpenExpired
            // 
            this.btnOpenExpired.Location = new System.Drawing.Point(301, 160);
            this.btnOpenExpired.Name = "btnOpenExpired";
            this.btnOpenExpired.Size = new System.Drawing.Size(167, 47);
            this.btnOpenExpired.TabIndex = 2;
            this.btnOpenExpired.Text = "الادوية منتهية الصلاحية و البراد ";
            this.btnOpenExpired.UseVisualStyleBackColor = true;
            this.btnOpenExpired.Click += new System.EventHandler(this.btnOpenExpired_Click);
            // 
            // btnOpenPOS
            // 
            this.btnOpenPOS.Location = new System.Drawing.Point(301, 223);
            this.btnOpenPOS.Name = "btnOpenPOS";
            this.btnOpenPOS.Size = new System.Drawing.Size(167, 43);
            this.btnOpenPOS.TabIndex = 3;
            this.btnOpenPOS.Text = "واجهة البيع POS";
            this.btnOpenPOS.UseVisualStyleBackColor = true;
            this.btnOpenPOS.Click += new System.EventHandler(this.btnOpenPOS_Click);
            // 
            // btnOpenReports
            // 
            this.btnOpenReports.Location = new System.Drawing.Point(301, 281);
            this.btnOpenReports.Name = "btnOpenReports";
            this.btnOpenReports.Size = new System.Drawing.Size(167, 42);
            this.btnOpenReports.TabIndex = 4;
            this.btnOpenReports.Text = "التقارير و الارباح ";
            this.btnOpenReports.UseVisualStyleBackColor = true;
            this.btnOpenReports.Click += new System.EventHandler(this.btnOpenReports_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnOpenReports);
            this.Controls.Add(this.btnOpenPOS);
            this.Controls.Add(this.btnOpenExpired);
            this.Controls.Add(this.btnOpenCompanies);
            this.Controls.Add(this.btnOpenMediciines);
            this.Name = "MainForm";
            this.Text = "MainForm";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnOpenMediciines;
        private System.Windows.Forms.Button btnOpenCompanies;
        private System.Windows.Forms.Button btnOpenExpired;
        private System.Windows.Forms.Button btnOpenPOS;
        private System.Windows.Forms.Button btnOpenReports;
    }
}