﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pharmasese
{
    public  class Medicine
    {
        public int ID { get; set; }
        public string TradeName {  get; set; }
        public string ScienceName {  get; set; }
        public int Quantity {  get; set; }
        public double Price {  get; set; }
        public string CompanyName {  get; set; }
        public DateTime ExpiryDate { get; set; }

    }
}
