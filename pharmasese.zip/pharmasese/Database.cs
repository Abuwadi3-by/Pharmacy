﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pharmasese
{
    public static class Database
    {
        public static List<Medicine> Medicines = new List<Medicine>();
        public static List<Company> Companies = new List<Company>();

        public static List<Invoice> Invoices = new List<Invoice>();

        
        public static void InitializeData()
        {
           
            Companies.Add(new Company { ID = 1, Name = "Alpha" });
            Companies.Add(new Company { ID = 2, Name = "Diamond" });

           
            Medicines.Add(new Medicine { ID = 1, TradeName = "Panadol", ScienceName = "Paracetamol", Quantity = 50, Price = 1500, CompanyName = "Alpha", ExpiryDate = new DateTime(2027, 5, 1) });
            Medicines.Add(new Medicine { ID = 2, TradeName = "Profinal", ScienceName = "Ibuprofen", Quantity = 20, Price = 2000, CompanyName = "Diamond", ExpiryDate = new DateTime(2025, 12, 1) }); 
        }
    }
}
