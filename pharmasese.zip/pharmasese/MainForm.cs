﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pharmasese
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            Database.InitializeData();
        }

        private void btnOpenMediciines_Click(object sender, EventArgs e)
        {
            MedicinesForm frm = new MedicinesForm();
            frm.ShowDialog(); 
        }

        private void btnOpenCompanies_Click(object sender, EventArgs e)
        {
            
  
  CompaniesForm frm = new CompaniesForm();
            frm.ShowDialog();
        }

        private void btnOpenExpired_Click(object sender, EventArgs e)
        {
            ExpiredForm frm = new ExpiredForm();
            frm.ShowDialog();
        }

        private void btnOpenPOS_Click(object sender, EventArgs e)
        {
            POSForm frm = new POSForm();
            frm.ShowDialog();
        }

        private void btnOpenReports_Click(object sender, EventArgs e)
        {
            ReportsForm frm = new ReportsForm();
            frm.ShowDialog();
        }
    }
}
