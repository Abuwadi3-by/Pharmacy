﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pharmasese
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string Username1 = "Scoot";
            string Password1 = "tiger13";
            if(txtName.Text== Username1&&txtPass1.Text==Password1)
            {
                MessageBox.Show("تمت عملية تسجيل الدخول بنجاح!", "مرحباً بك", MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.Hide();

                MainForm main = new MainForm(); 
                main.ShowDialog(); 

                this.Close(); 
            }
            else
            {
                
                MessageBox.Show("اسم المستخدم أو كلمة المرور خاطئة! يرجى إعادة المحاولة.", "خطأ في الدخول", MessageBoxButtons.OK, MessageBoxIcon.Error);

               
                txtPass1.Clear();
                txtPass1.Focus();
            }
        }
    }
}
