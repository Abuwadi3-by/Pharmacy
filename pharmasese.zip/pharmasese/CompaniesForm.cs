﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pharmasese
{
    public partial class CompaniesForm : Form
    {
        public CompaniesForm()
        {
            InitializeComponent();
        }

        private void CompaniesForm_Load(object sender, EventArgs e)
        {
            dgvCompanies.DataSource = null;
            dgvCompanies.DataSource = Database.Companies;
        }

        private void btnAddCompany_Click(object sender, EventArgs e)
        {
            if (txtCompanyName.Text == "")
            {
                MessageBox.Show("الرجاء كتابة اسم الشركة أولاً!", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Company comp = new Company
            {
                ID = Database.Companies.Count + 1,
                Name = txtCompanyName.Text
            };

            Database.Companies.Add(comp);

           
            dgvCompanies.DataSource = null;
            dgvCompanies.DataSource = Database.Companies;

            txtCompanyName.Clear();
            MessageBox.Show("تمت إضافة الشركة بنجاح!", "نجاح", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnDeleteCompany_Click(object sender, EventArgs e)
        {
            if (dgvCompanies.CurrentRow != null)
            {
                Company selected = (Company)dgvCompanies.CurrentRow.DataBoundItem;
                Database.Companies.Remove(selected);

                dgvCompanies.DataSource = null;
                dgvCompanies.DataSource = Database.Companies;
                MessageBox.Show("تم حذف الشركة بنجاح!", "نجاح", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
