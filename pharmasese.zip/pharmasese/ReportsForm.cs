﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pharmasese
{
    public partial class ReportsForm : Form
    {
        public ReportsForm()
        {
            InitializeComponent();
        }

        private void btnGenersteReport_Click(object sender, EventArgs e)
        {
            DateTime startDate = dtpStart.Value.Date;
            DateTime endDate = dtpEnd.Value.Date.AddDays(1); 

            if (cmbSortOrder.SelectedItem == null)
            {
                MessageBox.Show("الرجاء اختيار نوع الترتيب (تصاعدي أو تنازلي)!", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            
            var filteredInvoices = Database.Invoices.Where(i => i.SaleDate >= startDate && i.SaleDate < endDate).ToList();

           
            
            double totalRevenue = 0;
            List<InvoiceItem> allSoldItems = new List<InvoiceItem>();

            foreach (var inv in filteredInvoices)
            {
                totalRevenue += inv.TotalInvoicePrice;
                foreach (var item in inv.Items)
                {
                    allSoldItems.Add(item);
                }
            }

            
            if (cmbSortOrder.SelectedItem.ToString() == "تصاعدي")
            {
                allSoldItems = allSoldItems.OrderBy(x => x.TotalItemPrice).ToList();
            }
            else
            {
                allSoldItems = allSoldItems.OrderByDescending(x => x.TotalItemPrice).ToList();
            }

           
            string reportText = $"======= تقرير المبيعات والأرباح =======\n";
            reportText += $"الفترة من: {startDate.ToString("yyyy-MM-dd")} إلى: {dtpEnd.Value.ToString("yyyy-MM-dd")}\n";
            reportText += $"====================================\n\n";

            reportText += "1. الكميات المباعة وتفاصيل المواد:\n";
            foreach (var item in allSoldItems)
            {
                reportText += $"- دواء: {item.MedicineName} ({item.CompanyName}) -> الكمية المباعة: {item.QuantitySold} | العائد: {item.TotalItemPrice} ل.س\n";
            }

            reportText += "\n------------------------------------\n";
            reportText += $"2. صافي الأرباح والإيرادات الكلية للمبيعات:\n";
            reportText += $"إجمالي الأرباح في هذه الفترة = {totalRevenue} ل.س\n";
            reportText += $"====================================";

            
            rtbReportResult.Text = reportText;

            MessageBox.Show("تم توليد التقرير بنجاح وعرض صافي الأرباح!", "نجاح", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
