﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pharmasese
{
    public class Invoice
    {
            public int InvoiceID { get; set; }
            public DateTime SaleDate { get; set; }

            public double TotalInvoicePrice { get; set; }
        public List<InvoiceItem> Items { get; set; } = new List<InvoiceItem>();


    }
}
